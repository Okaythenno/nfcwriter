
import SwiftUI

@main
struct AmiiboWriterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
